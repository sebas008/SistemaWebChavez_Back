﻿namespace Chavez_Logistica.Entities
{
    public class Usuario
    {
        public int IdUsuario { get; set; }
        public string UsuarioLogin { get; set; } = null!;
        public string Nombres { get; set; } = null!;
        public string? Email { get; set; }
        public bool Activo { get; set; }
        public DateTime FechaCreacion { get; set; }
        public byte[]? PasswordHash { get; set; }
        public byte[]? PasswordSalt { get; set; }
    }
}
